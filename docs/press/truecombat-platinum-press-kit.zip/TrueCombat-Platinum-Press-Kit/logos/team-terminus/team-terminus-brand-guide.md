# Team Terminus brand kit

The studio mark is a machined metal plate with the Twin T stencilled through it and a red hazard corner. It was built to sit beside the TrueCombat: Platinum game logo and the Platinum Engine Hexcore mark, and it uses the same palette and type.

## Contents

| Folder | What |
|---|---|
| `svg/` | Vector masters, text converted to outlines. `symbol`, `symbol-small`, `horizontal`, `stacked`, `wordmark`, `icon`, `icon-small`, each in `dark` / `light` / `white` / `black` (icons in dark and light only). |
| `png/` | Transparent renders: symbol 4096 + 1024, symbol-small 512, horizontal 4800, stacked 3200, wordmark 3200, app icon 1024 to 16 px. |
| `ico/` | Windows icons (256 to 16 px), dark and light. |
| `placements/` | Intro splash cards (3840x2160 and 1920x1080, dark and light), credits mockup, website Studio page mockup. |
| `team-terminus-guidelines.png` | One-page guidelines sheet. |
| `source/` | Generator (`final.py` for the logo set, `mkpages.py` for the placements; needs Python fontTools and Node Playwright). |

## Which version to use

- **Dark** (platinum metal, `#D7193A` red): the default. Use it on Ink `#0E0E10` or dark footage.
- **Light** (gunmetal, `#C8102E` red): for white or light grey backgrounds.
- **White / Black**: one-colour versions for print, embroidery, watermarks, overlays and anything that can't carry a gradient.
- **Symbol-small / icon-small**: at 64 px and below. These drop the keyline and rivets and widen the stencil cuts so the mark holds together.
- **Stacked**: splash screens, title cards and the website Studio page.
- **Horizontal**: credits, footers, partner rows and the launcher.

## Colour

| Name | Hex | Use |
|---|---|---|
| Terminus Red | `#C8102E` | Light backgrounds, print |
| Terminus Red (screen) | `#D7193A` | Dark backgrounds |
| Ink | `#0E0E10` | Primary background |
| Platinum White | `#ECEEF1` | Wordmark on dark |
| Steel | `#9AA0A9` | Secondary text |
| Gunmetal | `#2A2C31` | Lines and panels |

The platinum gradient is part of the logo files. Don't rebuild it by hand.

## Type

- **Saira Condensed 600**: the wordmark, headlines, splash and credit titles. Always uppercase, tracked +5 to +8%.
- **Inter SemiBold / Medium**: body text, labels and the TEAM tag. Labels are uppercase, tracked +30%.

## Clear space and minimum size

- Clear space: X = one quarter of the plate width, on every side. Nothing goes inside that zone.
- Minimum size: mark 24 px; horizontal lockup 240 px wide.

## Don't

Don't stretch, rotate or recolour the mark. Don't add glows, bevels or chrome, and don't place it on a busy image without a dark scrim. Don't separate the red corner from the plate. Don't set TERMINUS in any other typeface.

## Placements

- **Intro**: the `splash-dark` card replaces the current TT "PRESENTS" card ahead of the game logo. Same timing, and the logo pops on the music hit.
- **Credits / exit screen**: game logo, then "Developed by" with the horizontal lockup, then the team, with "Powered by Platinum Engine" at the foot.
- **Website**: stacked lockup on the Studio page, small mark in the footer, and the icon as the favicon on studio pages.
- **Staff badge**: the in-game Twin T staff icon already uses this glyph and stays as it is.
