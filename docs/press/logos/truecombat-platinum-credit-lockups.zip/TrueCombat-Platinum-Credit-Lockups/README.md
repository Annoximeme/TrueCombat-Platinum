# Credit lockups

Ready-made combinations of the TrueCombat: Platinum, Team Terminus and Platinum Engine marks.

| File | What |
|---|---|
| `credits-strip-<version>` | DEVELOPED BY Team Terminus · POWERED BY Platinum Engine. SVG plus PNG at 4800 and 1600 px. For end cards, credits, video descriptions and articles. |
| `game-credits-<version>` | The game logo with the credit strip underneath. PNG at 4000 and 2000 px; the white and black versions are also SVG. |

Versions: **dark** for dark backgrounds, **light** for light backgrounds, **white** and **black** in one colour.

## Use

Free to use when writing about, streaming or making videos of TrueCombat: Platinum. Please don't recolour, stretch, rotate or redraw the logos, and leave clear space around them.

Questions: gianni@truecombat.eu · truecombat.eu/press
