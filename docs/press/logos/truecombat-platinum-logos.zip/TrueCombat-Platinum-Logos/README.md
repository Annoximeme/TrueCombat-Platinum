# TrueCombat: Platinum logo

| Folder | What |
|---|---|
| `png/truecombat-platinum-logo-<width>.png` | Full colour, transparent background, 256 to 6400 px wide. Works on dark and light backgrounds. |
| `png/truecombat-platinum-logo-white-<width>.png` | One colour, white. For dark photos, video overlays and watermarks. 512 to 6400 px. |
| `png/truecombat-platinum-logo-black-<width>.png` | One colour, black. For light backgrounds and print. 512 to 6400 px. |
| `svg/truecombat-platinum-logo-white.svg`, `-black.svg` | The one-colour logo as a vector, for print, merchandise, cutting and any size. |

The full colour logo is a metal artwork and exists as PNG only. For the largest prints, use the 6400 px file or the one-colour SVG.

## Use

Free to use when writing about, streaming or making videos of TrueCombat: Platinum. Please don't recolour, stretch, rotate or redraw the logos, and leave clear space around them.

Questions: gianni@truecombat.eu · truecombat.eu/press
