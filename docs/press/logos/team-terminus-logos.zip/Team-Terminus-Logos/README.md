# Team Terminus logos

The studio behind TrueCombat: Platinum.

| Folder | What |
|---|---|
| `svg/` | Vector masters. `symbol`, `symbol-small`, `horizontal`, `stacked`, `wordmark` and the app `icon`. |
| `png/` | Transparent PNGs: symbol 4096 to 256 px, horizontal 4800 to 600 px, stacked 3200 to 400 px, wordmark 3200 to 800 px, small symbol 512 px, app icons 1024 to 16 px. |
| `ico/` | Windows icons. |

## Which version

- **dark**: platinum metal with screen red. For dark backgrounds (the default).
- **light**: gunmetal with print red. For white and light grey backgrounds.
- **white / black**: one colour, for print, overlays and anything that can't carry a gradient.
- **symbol-small / icon-small**: for 64 px and below.
- **horizontal**: credits, footers, partner rows. **stacked**: title cards and splash screens.

Colours: Terminus Red #D7193A (screen) / #C8102E (print), Ink #0E0E10, Platinum White #ECEEF1, Steel #9AA0A9.

## Use

Free to use when writing about, streaming or making videos of TrueCombat: Platinum. Please don't recolour, stretch, rotate or redraw the logos, and leave clear space around them.

Questions: gianni@truecombat.eu · truecombat.eu/press
